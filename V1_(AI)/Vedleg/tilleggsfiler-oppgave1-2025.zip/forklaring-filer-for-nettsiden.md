Hei!

Her er foreløpige filer for nettsiden.

* "backgroundsnow.jpg" skal inn som bakgrunnsbilde for A i wireframe
* "maincontent.html" inneholder tre tekstbokser, for henholdsvis B1, B2 og B3 i wireframe: <!--Leftmost box-->, <!--Middle box-->, <!--Rightmost box-->
* i B1 skal det være et bilde: "tales2cities_serial.jpg"
* boksene i "bookboxes.html" skal inn i C
* bruk "menu.svg" for hamburgermeny
* boksene i D er beskrevet i “more-boxes-expanding.docx”, husk at de skal ekspandere, så uthevet skrift skal være *summary*-teksten

Hilsen Maryam